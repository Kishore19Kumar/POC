#include "object.hpp"

auto object::readFromFile(serverSocket& ssWrite, const std::string& objectPath, s3service::s3object& objResponse)
{
	std::string current_path= get_current_dir_name();
	std::string full_path=current_path+"/upload/"+  m_bucketName + "/";
	std::string obj=full_path+objectPath;
	//cout << obj << endl;
	std::ifstream iF(obj, std::ios::in | std::ios::binary);

	if (!iF)
	{
		std::cout << "File not found!";
		return false;
	}

	iF.seekg(0, std::ios::end);
	size_t size = iF.tellg();
	iF.seekg(0, std::ios::beg);

	char* data = new char[size];

	iF.read(data, size);
	auto ret = ssWrite.writeSocket(data, size);

	if (ret != "")
	{
		std::cout << ret << std::endl;
		return false;
	}

	objResponse.set_len(size);

	iF.close();

	return true;
}
void object::readDeletemarker(string objectPath, string m_bucketName)
{
	std::string current_path = get_current_dir_name();
	std::string full_path =current_path+"/upload/"+  m_bucketName + "/";
	std::string obj = full_path + objectPath;
	//cout << obj << endl;
	std::ifstream iF(obj, std::ios::in | std::ios::binary);

	if (!iF)
	{
		std::cout << "File not found!";
		return;
	}

	iF.seekg(0, std::ios::end);
	size_t size = iF.tellg();
	iF.seekg(0, std::ios::beg);

	char* data = new char[size];	
	iF.read(data, size);
	
	current_path= get_current_dir_name();
	full_path=current_path+"/deletedfile/"+ m_bucketName + "/";
	
	boost::filesystem::create_directories(full_path);
	std::string m_object_N = full_path + objectPath;
	//cout << full_path << endl;
	
	std::ofstream oF(m_object_N.c_str(), std::ios::out | std::ios::binary);
	
	oF.write(data, size);
    	oF.close();
}
void object::nameObject(const std::string& filename,s3service::s3object& objectResponse,std::string BucketVersion){
    
    std::string new_filename=filename;
    if(BucketVersion=="Enable"){
    
        // get the extension of the file
            size_t extension_index = filename.find_last_of(".");
            
            std::string extension;
            
            if (extension_index != std::string::npos)
            {
            extension = filename.substr(extension_index);
        }
        
        // create the new filename with extension
        std::ostringstream oss;
        
            oss << filename.substr(0, (extension_index-21)) << extension;
            
            new_filename = oss.str();
            
            objectResponse.set_objectname(new_filename);
        }
        else
        {
            	objectResponse.set_objectname(new_filename);
        }
}

bool object::writeToFile(serverSocket& ss, s3service::s3object& objectRequest)
{
	int size = 0;
	std::string current_path= get_current_dir_name();
	std::string full_path=current_path+"/upload/"+ m_bucketName + "/";
	
	boost::filesystem::create_directories(full_path);
	std::string m_object_N = full_path+ m_objectName;
	//cout << full_path << endl;
	
	std::ofstream oF(m_object_N.c_str(), std::ios::out | std::ios::binary);

	auto ret = ss.readSocket(m_data, objectRequest.len());

	if (ret != "")
	{
		std::cout << ret << std::endl;
		return false;
	}

    oF.write(&m_data[0], objectRequest.len());
    oF.close();
    std::ifstream iF(m_object_N.c_str(), std::ios::in | std::ios::binary);

	if (!iF)
	{
		std::cout << "File not found!";
		return false;
	}

	iF.seekg(0, std::ios::end);
	int siz=iF.tellg();
	ostringstream str1;
	str1 << siz;
	m_fileSize=str1.str();
	
	m_fileSize.append("_bytes");

    return true;
}
string object::getBucketVersion()
{
	return m_versionStatus;
}

void object::setClassVariables(database& d)
{
	std::vector<std::vector<std::string>> result;

	int retcode = d.executeQuery("Select * from  Msys_Objects where objectName = '" + m_objectName + "' AND bucketId = '" + m_bucketId + "'", result);

	if (retcode != 0)
	{
		std::cout << "ExecuteQuery Failed" << std::endl;
		return;
	}

	if (result.empty())
	{
		m_bExists = false;
		m_objectNameToCheck = "";
		m_objectId = "";
		m_creationTimestamp = "";
		m_data = std::vector<char>();
	}
	else
	{
		m_bExists = true;

		m_objectId = result[0][0];
		m_versionStatus = result[0][1];
		m_objectNameToCheck = result[0][2];
		m_creationTimestamp = result[0][5];
		m_data = std::vector<char>();
	}
}

inline void object::setData(const std::vector<char>& data)
{
    m_data = data;
}

object::object(const std::string& bucketId, const std::string& objectName, database& d)
{
    m_bucketId = bucketId;
    m_objectName = objectName;
    m_bExists = false;

    setClassVariables(d);
}
void object::setClassVariablesBasedonVersionId(database& d)
{
	std::vector<std::vector<std::string>> result;

	int retcode = d.executeQuery("Select * from  Msys_Objects where bucketId = '" + m_bucketId + "' AND objectVersion = '" + m_versionId + "'", result);

	if (retcode != 0)
	{
		std::cout << "ExecuteQuery Failed" << std::endl;
		return;
	}

	if (result.empty())
	{
		m_bExists = false;
		m_versionStatus = "";
		m_objectId = "";
		m_creationTimestamp = "";
		m_data = std::vector<char>();
		m_objectName = "";
	}
	else
	{
		m_bExists = true;

		m_objectId = result[0][0];
		m_versionStatus = result[0][1];
		m_creationTimestamp = result[0][5];
		m_objectName = result[0][2];
		m_versionId1 = result[0][4];
		m_data = std::vector<char>();
	}
}

object::object(const std::string& bucketId,database& d,const std::string versionId)
{
	m_bucketId = bucketId;
   	m_versionId = versionId;
    	m_bExists = false;
    	setClassVariablesBasedonVersionId(d);
}

std::string object::generateVersionId(const std::string& filename)
{
    std::ifstream file(filename, std::ios::binary);
    if (!file) {
        std::cerr << "Error opening file " << filename << std::endl;
        return "";
    }

    std::stringstream buffer;
    buffer << file.rdbuf();

    std::string contents = buffer.str();

    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(contents.c_str()), contents.length(), hash);

    std::stringstream versionId;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        versionId << std::hex << static_cast<int>(hash[i]);
    }

    return versionId.str();
}

void object::putObject(serverSocket& ss, s3service::s3object& objectRequest, s3service::s3object& objectResponse, database& d,std::string BucketVersion,std::string bucketname)
{

	m_bucketName = bucketname;
	if(BucketVersion == "Enable")
	{
		size_t extension_index = m_objectName.find_last_of(".");
	    	string extension;
	    	if (extension_index != string::npos) {
			extension = m_objectName.substr(extension_index);
	    	}
	    	std::vector<std::vector<std::string>> result;
	    	m_creationTimestamp = getCurrentTimeStamp();
	    	
		std::ostringstream oss;
	    	oss << m_objectName.substr(0, extension_index) << "_" << m_creationTimestamp << extension;
	    	m_objectName = oss.str();
	    	
		std::string current_path = get_current_dir_name();
		std::string full_path = current_path + "/upload/" + m_bucketName + "/";
	    	std::string m_object_N = full_path + m_objectName;
	    	
		if (m_bExists)
	   		{
				writeToFile(ss, objectRequest);
				//cout << m_object_N << endl;
				m_versionId = object::generateVersionId(m_object_N);
	
				m_objectId = "object" + getUniqueId();
			       int retcode = d.executeQuery("Insert into Msys_Objects (objectId,VersionStatus, objectName, objectsize, objectVersion, creationTimestamp, bucketId) " \
				    			"values "\
"('"+ m_objectId +"', '"+ BucketVersion +"', '"+ m_objectName +"', '"+  m_fileSize +"', '"+ m_versionId +"', '"+ m_creationTimestamp +"', '"+ m_bucketId +"')");
				if (retcode != 0)
				{
					std::cout << "ExecuteQuery Failed" << std::endl;
					return;
				}
			}
		else 
		{
				writeToFile(ss, objectRequest);
				m_versionId = object::generateVersionId(m_object_N);
				m_bExists = true;
				m_objectId = "object" + getUniqueId();
				int retcode = d.executeQuery("Insert into Msys_Objects " \
				    			"(objectId, VersionStatus,objectName,objectsize, objectVersion, creationTimestamp, bucketId) " \
				    			"values " \
"('"+ m_objectId +"', '"+ BucketVersion +"', '"+ m_objectName +"','"+ m_fileSize +"' , '"+ m_versionId +"' , '"+ m_creationTimestamp +"', '"+ m_bucketId +"')");


	    			if (retcode != 0)
				{
					std::cout << "ExecuteQuery Failed" << std::endl;
					return;
				}
		}

	    			
	    }
		
	
	
	else if(BucketVersion == "Disable"){
		if (m_bExists)
   		{
			writeToFile(ss, objectRequest);
			m_objectId = "object" + getUniqueId();

			int retcode = d.executeQuery("Insert into Msys_Objects " \
			    			"(objectId, VersionStatus,objectName, objectsize,creationTimestamp, bucketId) " \
			    			"values " \
"('"+ m_objectId +"', '"+ BucketVersion +"', '"+ m_objectName +"', '"+ m_fileSize +"', '"+ m_creationTimestamp +"', '"+ m_bucketId +"')");
							
    			if (retcode != 0)
			{
				std::cout << "ExecuteQuery Failed" << std::endl;
				return;
			}
		}

		else
		{
			writeToFile(ss, objectRequest);
			m_bExists = true;
			m_creationTimestamp = getCurrentTimeStamp();
			m_objectId = "object" + getUniqueId();

			int retcode = d.executeQuery("Insert into Msys_Objects " \
			    			"(objectId, VersionStatus,objectName, objectsize, creationTimestamp, bucketId) " \
			    			"values " \
"('"+ m_objectId +"', '"+ BucketVersion +"', '"+ m_objectName +"','"+ m_fileSize +"','"+ m_creationTimestamp +"', '"+ m_bucketId +"')");

    			if (retcode != 0)
			{
				std::cout << "ExecuteQuery Failed" << std::endl;
				return;
			}

    			
    			}
	
		}
    
}

object::object(database& d, std::string bucketId, std::string markerId)
{
	m_bucketId = bucketId;
	m_markerId = markerId;
	setClassVariablesBasedonDeleteMarkerId(d);
}

void object::setClassVariablesBasedonDeleteMarkerId(database& d)
{
	std::vector<std::vector<std::string>> result;

	int retcode = d.executeQuery("Select * from  Msys_DeleteMarker where deleteMarkerID = '" + m_markerId + "' AND bucketId = '" + m_bucketId + "'", result);

	if (retcode != 0)
	{
		std::cout << "ExecuteQuery Failed" << std::endl;
		return;
	}

	if (result.empty())
	{
		m_bExists = false;
	}
	else
	{
		m_bExists = true;
	}
}

void object::retriveDeletemarker(string objectPath, string m_bucketName)
{
	std::string current_path = get_current_dir_name();
	std::string full_path =current_path+"/deletedfile/"+  m_bucketName + "/";
	std::string obj = full_path + objectPath;
	//cout << obj << endl;
	std::ifstream iF(obj, std::ios::in | std::ios::binary);

	if (!iF)
	{
		std::cout << "File not found!";
		return;
	}

	iF.seekg(0, std::ios::end);
	size_t size = iF.tellg();
	iF.seekg(0, std::ios::beg);

	char* data = new char[size];	
	iF.read(data, size);
	
	current_path= get_current_dir_name();
	full_path=current_path+"/upload/"+ m_bucketName + "/";
	
	boost::filesystem::create_directories(full_path);
	std::string m_object_N = full_path + objectPath;
	//cout << full_path << endl;
	
	std::ofstream oF(m_object_N.c_str(), std::ios::out | std::ios::binary);
	
	oF.write(data, size);
    	oF.close();
}

void object::getDeleteMarker(s3service::s3object& objectResponse, database& d)
{
	if((m_bExists == true))
	{
		std::vector<std::vector<std::string>> result;
		int retcode = d.executeQuery("Select bucketName, objectId, bucketId from  Msys_DeleteMarker where deleteMarkerID = '" + m_markerId + "' AND bucketId = '" + m_bucketId + "'", result);

			if (retcode != 0)
			{
				std::cout << "ExecuteQuery Failed in Msys_DeleteMarker" << std::endl;
				m_error = "ExecuteQuery Failed in Msys_DeleteMarker.";
				auto err = objectResponse.add_errorinfo();

				err->set_errortype("Object");
				err->set_errorcode("Nosuch object in DeleteMarker");
				err->set_key(m_objectName);
				err->set_errormessage(m_error);
				return;
			}
		
		for(int i = 0; i < result.size(); i++)
		{
			string bucketName = result[i][0];
			string objId = result[i][1];
			string bucketId = result[i][2];
			
			
			
		std::vector<std::vector<std::string>> result1;
		int retcode = d.executeQuery("Select * from  Msys_DeleteMarker where objectId = '" + objId + "' AND bucketId = '" + bucketId + "'", result1);
			//string objId = result1[0][0];
			string versionstatus = result1[0][1];
			string objName = result1[0][2];
			string objsize = result1[0][3];
			string versionId = result1[0][4];
			string creationTime = result1[0][5];
			//string bucketId = result1[0][6];

			retcode = d.executeQuery("Insert into Msys_Objects " \
			    			"(objectId, VersionStatus,objectName, objectsize, objectVersion,creationTimestamp, bucketId) " \
			    			"values " \
"('"+ objId +"', '"+ versionstatus +"', '"+ objName +"', '"+ objsize +"', '" + versionId +"', '"+ creationTime +"', '"+ bucketId +"')");

			if (retcode != 0)
			{
				std::cout << "ExecuteQuery Failed in Msys_DeleteMarker" << std::endl;
				m_error = "ExecuteQuery Failed in deleting Msys_DeleteMarker.";
				auto err = objectResponse.add_errorinfo();

				err->set_errortype("Object");
				err->set_errorcode("Nosuch object in deleting DeleteMarker");
				err->set_key(m_markerId);
				err->set_errormessage(m_error);
				return;
			}
			retriveDeletemarker(objName, bucketName);
			std::string current_path= get_current_dir_name();
			std::string full_path = current_path + "/deletedfile/" + bucketName + "/" + objName;
			int ret = remove(full_path.c_str());
			if (ret != 0)
			{
				std::cout << "Error in removing file delete file in for loop" << std::endl;
			}
			
			retcode = d.executeQuery("DELETE from Msys_DeleteMarker Where  objectId = '" + objId + "' AND bucketId = '" + bucketId + "'");

			if (retcode != 0)
			{
				std::cout << "ExecuteQuery Failed in Msys_DeleteMarker" << std::endl;
				m_error = "ExecuteQuery Failed in deleting Msys_DeleteMarker.";
				auto err = objectResponse.add_errorinfo();

				err->set_errortype("Object");
				err->set_errorcode("Nosuch object in deleting DeleteMarker");
				err->set_key(m_markerId);
				err->set_errormessage(m_error);
				return;
			}
		}
		
	}
		else
	{
		m_error = "The specific object does not exists.";
		auto err = objectResponse.add_errorinfo();

		err->set_errortype("Object");
		err->set_errorcode("Nosuch object in DeleteMarker");
                err->set_key(m_objectName);
		err->set_errormessage(m_error);
	}
}

object::object(std::string bucketId, std::string objectName)
{
	m_bucketId = bucketId;
    	m_objectName = objectName;
}
std::string object::setvariable(database& d)
{
	std::vector<std::vector<std::string>> result;
	int retcode = d.executeQuery("select VersionStatus from Msys_DeleteMarker where objectName = '" + m_objectName + "' AND bucketId = '" + m_bucketId + "'", result);
	if(result.empty())
	{
		return "";
	}
	if (retcode != 0)
	{
		std::cout << "ExecuteQuery Failed for Currentversion" << std::endl;
		return "";
	}
	return result[0][0];
}
void object::ListdeleteMarkerObject(s3service::s3object& objectResponse, database& d)
{
	std::string BucketVersion = setvariable(d);
	if(BucketVersion == "Enable")
    	{
    		std::vector<std::vector<std::string>> result;
      
		size_t extension_index = m_objectName.find_last_of(".");
			    
		std::string extension;
		    
		if (extension_index != std::string::npos)
		{
			extension = m_objectName.substr(extension_index);
		}
		
	   
	      	std::ostringstream oss;
		
		oss << m_objectName.substr(0, (extension_index-21)) << "%" << extension;
		
		    
		 std::string new_filename =  oss.str();
		 	
	int retcode = d.executeQuery("select distinct(deleteMarkerID) from Msys_DeleteMarker where objectName like '" + new_filename + "' AND bucketId = '" + m_bucketId + "'", result);

		if (retcode != 0)
		{
			std::cout << "ExecuteQuery Failed for Currentversion" << std::endl;
			return;
		}
		std::string markerId = result[0][0];
		objectResponse.set_listdeletemarker(markerId);
		return;
       }
       
      	else
	{
		m_error = "The specific object does not exists.";
		auto err = objectResponse.add_errorinfo();

		err->set_errortype("Object");
		err->set_errorcode("Nosuch object");
                err->set_key(m_objectName);
		err->set_errormessage(m_error);
	}
       
}
void object::deleteObject(database& d,s3service::s3object& objectResponse,std::string bucketname, std::string BucketVersion)
{

	m_bucketName = bucketname;
	if((m_bExists) && (m_objectName == m_objectNameToCheck) && (BucketVersion == "Disable"))
	{
				
		int retcode = d.executeQuery("DELETE from Msys_Objects Where objectId = '" + m_objectId + "' AND bucketId = '" + m_bucketId + "'");

		if (retcode != 0)
		{
			std::cout << "ExecuteQuery Failed" << std::endl;
			return;
		}
		
		std::string current_path= get_current_dir_name();
		std::string full_path = current_path + "/upload/" + m_bucketName + "/" + m_objectName;
		int ret = remove(full_path.c_str());
		
		if (ret != 0)
		{
			std::cout << "Error in removing file" << std::endl;
		}
		return;	
	}
	std::string new_filename;
	std::vector<std::vector<std::string>> result;
    	if(BucketVersion == "Enable")
    	{
    
      
		size_t extension_index = m_objectName.find_last_of(".");
			    
		std::string extension;
		    
		if (extension_index != std::string::npos)
		{
			extension = m_objectName.substr(extension_index);
		}
		
	   
	      	std::ostringstream oss;
		
		oss << m_objectName.substr(0, (extension_index-21)) << "_____-%" << extension;
		
		    
		 new_filename =  oss.str();
		 	
	int retcode = d.executeQuery("select convert(DATETIME, upper(creationTimestamp)) DateTime ,objectName from Msys_Objects where objectName Like '" + new_filename + "' AND bucketId = '" + m_bucketId + "' order by DateTime DESC", result);

		if (retcode != 0)
		{
			std::cout << "ExecuteQuery Failed for Currentversion" << std::endl;
			return;
		}
       }
	

		
	if((m_bExists) && (m_objectName == m_objectNameToCheck) && (result[0][1] == m_objectName ) && (BucketVersion == "Enable"))
	{
		string deletemarkerId = "deletemarker" + getUniqueId();
		for(int i = 0; i < result.size(); i++)   
		{
			string objName = result[i][1];
			readDeletemarker(objName, m_bucketName);
			std::vector<std::vector<std::string>> result1;
			
			int retcode = d.executeQuery("Select * from  Msys_Objects where objectName = '" + objName + "' AND bucketId = '" + m_bucketId + "'", result1);

			if (retcode != 0)
			{
				std::cout << "ExecuteQuery Failed getting objectID" << std::endl;
				return;
			}
			string objId = result1[0][0];
			string versionStatus = result1[0][1];
			//string objName = result1[0][2];
			string objSize = result1[0][3];
			string versionId = result1[0][4];
			string creationTime = result1[0][5];
			string bucketId = result1[0][6];
			string bucketName = m_bucketName;
			string deletedtime = getCurrentTimeStamp();
			
			retcode = d.executeQuery("Insert into Msys_DeleteMarker(objectId,VersionStatus, objectName, objectsize, objectVersion, creationTimestamp, bucketId, deleteMarkerID, bucketName, DeletedCreationTimestamp) " \
				    			"values "\
"('"+ objId +"', '"+ versionStatus +"', '"+ objName +"', '"+  objSize +"', '"+ versionId +"', '"+ creationTime +"', '"+ bucketId +"', '"+ deletemarkerId + "', '" + bucketName + "', '" + deletedtime + "')");
				if (retcode != 0)
				{
					std::cout << "ExecuteQuery Failed" << std::endl;
					return;
				}

			retcode = d.executeQuery("DELETE from Msys_Objects Where objectId = '" + objId + "' AND bucketId = '" + m_bucketId + "'");

			if (retcode != 0)
			{
				std::cout << "ExecuteQuery Failed for deleting object in for loop" << std::endl;
				return;
			}
			
			std::string current_path= get_current_dir_name();
			std::string full_path = current_path + "/upload/" + m_bucketName + "/" + objName;
			int ret = remove(full_path.c_str());
			
			if (ret != 0)
			{
				std::cout << "Error in removing file delete file in for loop" << std::endl;
			}
		}
	}
	else if ((m_bExists) && (m_objectName == m_objectNameToCheck) && (result[0][1] != m_objectName )  && (BucketVersion == "Enable"))
	{
		
				int retcode = d.executeQuery("DELETE from Msys_Objects Where objectId = '" + m_objectId + "' AND bucketId = '" + m_bucketId + "'");

		if (retcode != 0)
		{
			std::cout << "ExecuteQuery Failed" << std::endl;
			return;
		}
		
		std::string current_path= get_current_dir_name();
		std::string full_path = current_path + "/upload/" + m_bucketName + "/" + m_objectName;
		int ret = remove(full_path.c_str());
		
		if (ret != 0)
		{
			std::cout << "Error in removing file" << std::endl;
		}
	}
	

	else
	{
		m_error = "The specific object does not exists.";
		auto err = objectResponse.add_errorinfo();

		err->set_errortype("Object");
		err->set_errorcode("Nosuch object");
                err->set_key(m_objectName);
		err->set_errormessage(m_error);
	}
	
}
void object::downloadObject(serverSocket& ssWrite,  s3service::s3object& objectResponse, std::string bucketname)
{
    if (!m_bExists)
    {
        m_error = "The specific key does not exists.";

		auto err = objectResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoSuchKey");
                err->set_key(m_objectName);
		err->set_errormessage(m_error);
    }
    else if((m_bExists) && (m_objectName == m_objectNameToCheck))
    {
    	m_bucketName = bucketname;
    	cout << m_objectName << " " <<  m_objectNameToCheck << endl;
    	object::nameObject(m_objectName,objectResponse,m_versionStatus);
    
        auto ret = readFromFile(ssWrite, m_objectName, objectResponse);

        if (!ret)
        {
        	std::cout << "Read from file failed" << std::endl;
        	m_error = "Read from file failed.";

		auto err = objectResponse.add_errorinfo();


		err->set_errortype("Sender");
		err->set_errorcode("NoSuchKey");
                err->set_key(m_objectName);
		err->set_errormessage(m_error);
        }
    }
    else 
    {
    	     	m_error = "The object does not exists.";

		auto err = objectResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoSuchKey");
              	err->set_key(m_objectName);
		err->set_errormessage(m_error);
    
    }
}

void object::downloadObjectByVersion(serverSocket& ssWrite, s3service::s3object& objectResponse, std::string bucketname)
{
	if (!m_bExists)
    	{
        	m_error = "The specific key does not exists.";

		auto err = objectResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoSuchKey");
		err->set_key(m_objectName);
		err->set_errormessage(m_error);
    	}
    else if(m_versionId1 != m_versionId)
    {
    	        m_error = "The specific version does not exists.";

		auto err = objectResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoversionID");
		err->set_key(m_objectName);
		err->set_errormessage(m_error);
    }
    	
    else if((m_bExists) && (m_versionId != "NULL") )
    {
    	m_bucketName = bucketname;
    	object::nameObject(m_objectName,objectResponse,m_versionStatus);
        auto ret = readFromFile(ssWrite,m_objectName, objectResponse);

        if (!ret)
        {
        	std::cout << "Read from file failed" << std::endl;
        	m_error = "Read from file failed.";

		auto err = objectResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoSuchKey");
                err->set_key(m_objectName);
		err->set_errormessage(m_error);
        }
    }
}

inline std::string object::getObjectName()
{
    return m_objectName;
}

inline std::string object::getBucketId()
{
    return m_bucketId;
}

inline std::string object::getObjectId()
{
	return m_objectId;
}

inline std::vector<char> object::getData()
{
    return m_data;
}

inline std::string object::getCreationTimestamp()
{
    return m_creationTimestamp;
}

inline bool object::doesObjectExists()
{
    return m_bExists;
}

std::string object::getErrorMessage()
{
	return m_error;
}

object::~object()
{

}


void object::getObjectProperties(serverSocket& ss, s3service::s3object& objectRequest, s3service::s3object& objectResponse, database& d)
{
    if (!m_bExists)
    {
        m_error = "The specific key does not exists.";

		auto err = objectResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoSuchKey");
               err->set_key(m_objectName);
		err->set_errormessage(m_error);
    }
    else
    {
    	long long file_size = getFileSize(m_objectName);
    	objectResponse.set_len(file_size);
    }
}
void object::initMultiPartUpload(serverSocket& ss, s3service::s3object& objectRequest, s3service::s3object& objectResponse, database& d)
{
	// generate unique_mutil_part_id
	string unique_mutil_part_id = "123457"; // hard coded for time being , later need to generate by seeding time

	// set response
	objectResponse.set_multipartuniqueid(unique_mutil_part_id);
	//(unique_mutil_part_id);
	//push to cleanup queue with creation time

	//create folder in the name of unique_mutil_part_id
	boost::filesystem::create_directories(unique_mutil_part_id);
	std::cout << "***Mulitipart_Id_UK: " <<  unique_mutil_part_id << std::endl;
	
	
}
	
void object::putMultiPartUpload(serverSocket& ss, s3service::s3object& objectRequest, s3service::s3object& objectResponse, database& d)
{
	string unique_id = objectRequest.s3object::multipartuniqueid();
	string filepath = "123457/" + m_objectName;
	downloadFile(ss,filepath, objectRequest.len()  );
}
void object::completeMultiPartUpload(serverSocket& ss, s3service::s3object& objectRequest, s3service::s3object& objectResponse, database& d)
{
	string unique_id = objectRequest.s3object::multipartuniqueid();
	int arr_size = objectRequest.s3object::multipartlist_size();

	vector<string> v_arr_list;
	for(auto i = 0; i < arr_size; i++){
		v_arr_list.push_back(objectRequest.s3object::multipartlist(i));
	}

	//std::string out_file = "out_file";
    std::fstream fs(m_objectName , std::fstream::out | std::fstream::trunc); //truncate out file first if already exist

	for(unsigned int i = 0; i < v_arr_list.size(); i++ ){
		// 1) create path
		string file_name = v_arr_list[i];
		string tmp_path = unique_id + "/" + file_name;
		std::cout << "create path : " << tmp_path ;

		// 2) set in stream
        ifstream ifile(tmp_path.c_str(), ios::in); // Input stream class to operate on files.

        // 3) set out stream
        ofstream ofile( m_objectName , ios::out | ios::app); // Output stream class to operate on files.

        // 4) check if file exists
        if (!ifile.is_open()) {
            // file not found (i.e, not opened).
            cout << tmp_path << " : file not found" << endl;
            return;
        }
        // 5) append
        ofile << ifile.rdbuf();
       std::cout << "writing to " << m_objectName << " out file complete";
	}

	// 6) delete the multipart temp folder
	const boost::filesystem::path path( unique_id );
	try
	{
	    if ( boost::filesystem::exists( path ) )
	    {
	        //boost::filesystem::remove_all( path );
	    }
	}
	catch(boost::filesystem::filesystem_error const & e)
	{
		std::cout << "Deletion of multi-part " << path << " temporary folder failed";
	}

	// 7) putting object to bucket
	{
		m_bExists = true;
		m_creationTimestamp = getCurrentTimeStamp();
		m_objectId = "object" + getUniqueId();

		int retcode = d.executeQuery("Insert into Msys_Objects " \
				"(objectId, objectName, creationTimestamp, bucketId) " \
				"values " \
				"('" + m_objectId + "', '" + m_objectName + "', '" + m_creationTimestamp + "', '" + m_bucketId + "')");

		if (retcode != 0)
		{
			std::cout << "ExecuteQuery Failed" << std::endl;
			return;
		}
		std::cout << "Putting object to bucket success: " <<  m_bucketId;
	}
}
void object::abortMultiPartUpload(serverSocket& ss, s3service::s3object& objectRequest, s3service::s3object& objectResponse, database& d)
{
	    objectResponse.set_putid("654123");
}
void object::listMultiPartUpload(serverSocket& ss, s3service::s3object& objectRequest, s3service::s3object& objectResponse, database& d)
{
	objectResponse.set_putid("123457");
}
long object::getFileSize(std::string filename)
{
    struct stat stat_buf;
    int rc = stat(filename.c_str(), &stat_buf);
    return rc == 0 ? stat_buf.st_size : -1;
}
/*int object::uploadFile(serverSocket& ss, string file_name)
{
    int len = 64 * 1024;
    char sdbuf[len];
    try
    {
        bzero(sdbuf, len);
        int fs_block_sz;
        //FILE *fs = fopen(file_name.c_str(), "r");
        int fileFd = open(file_name.c_str(), O_RDONLY);
        if (fileFd < 0)
        {
            //printf("ERROR: File %s not found.\n", file_name.c_str());
            std::cout  <<  "File not found" << file_name;
        }
        
        int cli_id= ss.get_clientfd();
        
        while ((fs_block_sz = read(fileFd, sdbuf, len)) > 0)
        {
            if (send(cli_id, sdbuf, fs_block_sz, 0) < 0)
            {
                std::cout  <<  "ERROR: Failed to send file " << file_name.c_str() << " errno = " << errno ;
                return EXIT_FAILURE;
            }
            bzero(sdbuf, len);
            std::cout  <<  "-" ;
        }
        std::cout  <<  "Upload of file " << file_name.c_str()  << "was successfull" ;
    }
    catch (std::exception const &e)
    {
        std::cerr << e.what() << std::endl;
        std::cout  <<  "function:UploadFile";
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}*/
int object::downloadFile(serverSocket& ss, string file_name, unsigned long long bytes)
{
    int len = 4096;
    char buffer[len];
    int bytes_read = 0;
    try
    {
    	//open(filename, O_RDWR|O_CREAT, 0666)
        int fileFd = open(file_name.c_str(), O_CREAT|O_RDWR|O_CREAT,0666);
        if (fileFd < 0)
        {
            //printf("ERROR: File %s not found.\n", file_name.c_str());
            std::cout  <<  "File not found" << file_name << std::endl;
        }
        unsigned long long tot = 0;
       int cli_id= ss.get_clientfd();
        do
        {
            bytes_read = read(cli_id, buffer, sizeof(buffer));
            if (bytes_read > 0)
            {
                write(fileFd, buffer, bytes_read);
            }else if(bytes_read == 0){
                return EXIT_FAILURE;
            }
            tot += bytes_read;
            std::cout << "read bytes tot: " <<  tot;
        } while (tot < bytes);
        std::cout  <<  "Download of file " << file_name.c_str()  << "was successfull" ;
    }
    catch (std::exception const &e)
    {
        std::cerr << e.what() << std::endl;
        std::cout  <<  "function:DownloadFile";
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}


