#include "publisher.hpp"
#include "consumer.hpp"
#include "s3service.pb.h"
#include "clientsocket.hpp"

#include <iostream>
#include <thread>
#include <cstddef>
#include <experimental/filesystem>
#include <bits/stdc++.h>
#include <vector>

#include <sys/stat.h>
#include <boost/filesystem.hpp>
#include <bits/stdc++.h>
#include <iostream>
#include <cstdint>
#include <boost/filesystem.hpp>

#include <unistd.h>
#include <stdio.h>

#include <string>
#include <termios.h>


#include <cstdlib>
#include <cstring>
#include <fstream>
#include <netdb.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dirent.h>
#include<vector>
#include <sstream>
#include<signal.h>

std::string accountName, password;
const std::string operation;
const std::string suboperation;

void createAndPublishRequestPacket(publisher* pub)
{
	clientSocket cs("127.0.0.1", 8081);
	cs.createAndConnect();
		s3service::serviceRequestResponse request;
		
		if (operation == "Account")
		{
			request.set_entitytype(s3service::serviceRequestResponse::ACCOUNT);
			
			auto accountRequest  = request.add_account();
				
				if (suboperation=="CreateAccount")
				{
					accountRequest->set_accop(s3service::s3account::CREATE_ACCOUNT);
					break;
				}
				else if(suboperation == "DELETE_ACCOUNT")
				{
					accountRequest->set_accop(s3service::s3account::DELETE_ACCOUNT);
					break;
				}
			accountRequest->set_accountname(accountName);
			
			accountRequest->set_password(password);
		}
		

		auto serializedProto = request.SerializeAsString();
		
		pub->publishMessage(serializedProto, "test");

		sleep(3);
		}
		
}

void displayConsumedMessage(clientSocket& csRead, s3service::serviceRequestResponse serverresponse,Http::ResponseWriter response)
{
	auto entityType = serverresponse.entitytype();

	if (entityType == s3service::serviceRequestResponse::ACCOUNT)
	{
		for (int i = 0; i < serverresponse.account_size(); i++)
		{
			auto accountResponse = serverresponse.account(i);

			auto accountOp = accountResponse.accop();

			if (accountOp == s3service::s3account::CREATE_ACCOUNT)
			{
				if (accountResponse.errorinfo_size() == 0)
				{	
					std::string result = "Account created successfully";
					auto key = accountResponse.keys(0);
					
					response.send(Http::Code::Ok, result);
					response.send(Http::Code::Ok, accountResponse.accountid());
					response.send(Http::Code::Ok, key.accesskeyid());
					response.send(Http::Code::Ok, key.secretkey());
				}
				else
				{
					s3service::errorDetails error = accountResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::string error_result="Encountered an error while createAccount():"
					
					response.send(Http::Code::Ok, error_result);
					response.send(Http::Code::Ok, error.errortype());
					response.send(Http::Code::Ok,  error.errorcode());
					response.send(Http::Code::Ok, error.errormessage());
				}
			}
}
}
}
void handleOperation(const Rest::Request& request, Http::ResponseWriter response) 
{
	const auto& queryParams = request.query();

	    const std::string operation = queryParams.get("operation").value_or("");
	    accountName = std::stoi(queryParams.get("accountname").value_or("0"));
	    password = std::stoi(queryParams.get("password").value_or("0"));

	publisher pub("", "", "", "", "requestExchange");

	auto headers = pub.getHeaders();

	headers.insert({"Content-type", "text/text"});
	headers.insert({"Content-encoding", "UTF-8"});

	pub.addHeaders(headers);

	auto err = pub.init();

	if(err.size() != 0)
	{
		std::cout << "Error: " << err << std::endl;
	    return false;
	}

	err = pub.createAndBindQueue("requestQueue", "test");

	if(err.size() != 0)
	{
		std::cout << "Error: " << err << std::endl;
	    return false;
	}

	consumer cObj("", "", "", "", "responseQueue", "client");

	err = cObj.init();

	if (err.size() != 0)
	{
		std::cout << "Error consumer::init(): " << err << std::endl;
		return false;
	}

	err = cObj.bindToExchange("responseExchange", "test");

	if (err.size() != 0)
	{
		std::cout << "Error consumer::bindToExchange(): " << err << std::endl;
		return false;
	}

	clientSocket csRead("127.0.0.1", 9090);

	 auto ret = csRead.createAndConnect();

	if (ret != "")
	{
		std::cout << "cdRead.createAndConect() failed " << ret << std::endl;
		return -1;
	}

	std::thread th1(&createAndPublishRequestPacket, &pub);

	std::thread th2(&consumer::consumeMessage, &cObj);

	while (true)
	{
		for (size_t i = 0; i < consumer::m_consumeRequestMsg.size(); i++)
		{
			s3service::serviceRequestResponse serverresponse;

			serverresponse.ParseFromString(consumer::m_consumeRequestMsg[i]);

			std::cout << std::endl;
			std::cout << "*****************************************" << std::endl;
			std::cout << std::endl;

			displayConsumedMessage(csRead, serverresponse,response);

			std::cout << std::endl;
			std::cout << "*****************************************" << std::endl;
			std::cout << std::endl;

			consumer::m_consumeRequestMsg.erase(consumer::m_consumeRequestMsg.begin() + i);
			i--;
		}
	}

	th1.join();
	th2.join();

}
int main()
{
	Pistache::Address addr(Pistache::Ipv4::any(), Pistache::Port(8085));
    Pistache::Http::Endpoint server(addr);

    server.options().threads(1);

    Rest::Router router;
    Rest::Routes::Get(router, "/client", Rest::Routes::bind(&handleOperation));
    server.setHandler(router.handler());

    server.serve();
    
    server.shutdown();


	
    return 0;
}
