#include "bucket.hpp"

void bucket::setClassVariables(database& d)
{
	std::vector<std::vector<std::string>> result;

	int retcode = d.executeQuery("Select * from Msys_Buckets where bucketName = '" + m_bucketName + "' AND accountId = '" + m_accountId + "'", result);

	if (retcode != 0)
	{
		std::cout << "ExecuteQuery Failed" << std::endl;
		return;
	}

	if (result.empty())
	{
		m_bExists = false;
		m_arn = "";
		m_creationTimestamp = "";
		m_bucketId = "";
		m_tags = {};
		m_bucketVersion="";
	}

	else
	{

		m_bExists = true;
		m_bucketId = result[0][0];
		m_creationTimestamp = result[0][4];
		m_arn = result[0][3];
		m_bucketVersion=result[0][2];
		//need to chage order 
	}
}

void bucket::setTags(std::map<std::string, std::string>& m)
{
	m_tags = m;
}

bucket::bucket(const std::string& bucketName, const std::string& accountId, database& d)
{
    m_bucketName = bucketName;
    m_accountId = accountId;
    m_bExists = false;

    setClassVariables(d);
}

void bucket::createBucket(s3service::s3bucket& bucketResponse, database& d)
{
    if (m_bExists)
    {
        m_error = "The requested bucket name is not available. The bucket namespace is shared by all users of the system. Please select a different name and try again.";

		auto err = bucketResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("BucketAlreadyExists");
		err->set_errormessage(m_error);
    }
	else
	{
	   m_arn = "arn:aws:s3:::" + m_bucketName;
	   m_creationTimestamp = getCurrentTimeStamp();
	   m_bucketId = "bucket" + getUniqueId();
	   m_bExists = true;
	   m_bucketVersion="Disable";

	   int retcode = d.executeQuery("Insert into Msys_Buckets (bucketId, bucketName,bucketVersion, arn, creationTimestamp, accountId) values ('" + m_bucketId + "', '" + m_bucketName + "', '" + m_bucketVersion + "', '"+ m_arn + "', '" + m_creationTimestamp + "', '" + m_accountId + "')");

	   if (retcode != 0)
	   {
		   std::cout << "ExecuteQuery Failed" << std::endl;
		   return;
	   }
	}
}

void bucket::deleteBucket(s3service::s3bucket& bucketResponse, database& d)
{
    if (!m_bExists)
    {
        m_error = "The specified bucket does not exists";

		auto err = bucketResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoSuchBucket");
		err->set_errormessage(m_error);
    }
    else
	{
    	int retcode = d.executeQuery("Delete from Msys_Buckets WHERE bucketId = '" + m_bucketId + "'");

    	if (retcode != 0)
		{
			std::cout << "ExecuteQuery Failed" << std::endl;
			return;
		}
	}
}

void bucket::putBucketTags(std::map<std::string, std::string>& tags, s3service::s3bucket& bucketResponse, database& d)
{
	std::vector<std::vector<std::string>> result;

	if (!m_bExists)
    {
        m_error = "The specified bucket does not exists";

		auto err = bucketResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoSuchBucket");
		err->set_errormessage(m_error);
    }
	else
	{
		for (auto it = tags.begin(); it != tags.end(); it++)
		{
			if (m_tags.find(it->first) != m_tags.end())
			{
				m_error = "Cannot provide multiple Tags with the same key";

				auto err = bucketResponse.add_errorinfo();

				err->set_errortype("Sender");
				err->set_errorcode("InvalidTag");
				err->set_errormessage(m_error);	

				break;
			}
			else
			{
				m_tags.insert({it->first, it->second});

				int retcode = d.executeQuery("Insert into Msys_Bucket_Tags (bucketKey, bucketValue, bucketId) values ('" + it->first + "', '" + it->second + "', '" + m_bucketId + "')");

				if (retcode == -1)
				{
					std::cout << "Executequery failed" << std::endl;
					return;
				}
			}
		}
	}
}

void bucket::listBucketTags(s3service::s3bucket& bucketResponse)
{
	if (!m_bExists)
    {
        m_error = "The specified bucket does not exists";

		auto err = bucketResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoSuchBucket");
		err->set_errormessage(m_error);
    }
	else
	{
		for (auto it = m_tags.begin(); it != m_tags.end(); it++)
		{
			auto tag = bucketResponse.add_tag();

			tag->set_key(it->first);
			tag->set_value(it->second);
		}
	}
}
void bucket::list_object_version(s3service::s3bucket& bucketResponse,database& d)
{
	if(m_bExists)
	{
	   std::vector<std::vector<std::string>> result;
			int retcode = d.executeQuery("Select o.objectName, o.objectsize, o.VersionStatus, o.objectVersion from Msys_Buckets b JOIN Msys_Objects o ON b.bucketId=o.bucketId And b.bucketId='" + m_bucketId + "'", result);

	if (retcode != 0)
	{
		std::cout << "ExecuteQuery Failed" << std::endl;
		return;
	}
	std::string sendResponse;
	std::string str;
	for(int i=0;i<result.size();i++)
	  {
	  	for(int j=0;j<4;j++)
	  	{
	  	      str=result[i][j];
		      sendResponse.append(str);
		      sendResponse.append(" ");
		}
		
	  }
	  bucketResponse.set_list_object_versions(sendResponse);
	}
	else 
	{
		bucketResponse.set_list_object_versions("No Objects are found in the database. Please check the Bucket Name");
	}
}

void bucket::list_object(s3service::s3bucket& bucketResponse,database& d)
{	
	if(m_bExists)
	{
	   std::vector<std::vector<std::string>> result;
			int retcode = d.executeQuery("Select o.objectName from Msys_Buckets b JOIN Msys_Objects o ON b.bucketId=o.bucketId And b.bucketId='" + m_bucketId + "'", result);

	if (retcode != 0)
	{
		std::cout << "ExecuteQuery Failed" << std::endl;
		return;
	}
	std::string sendResponse;
	std::string str;
	for(int i=0;i<result.size();i++)
	  {

	  	      str=result[i][0];
		      sendResponse.append(str);
		      sendResponse.append(" ");
		
		
	  }
	  bucketResponse.set_list_object(sendResponse);
	}
	else 
	{
		bucketResponse.set_list_object_versions("No objects are found in the database. Please check the Bucket Name");
	}
}

/*void bucket::deleteBucketTags(s3service::s3bucket& bucketResponse, database& d)
{
	if (!m_bExists)
    {
        m_error = "The specified bucket does not exists";

		auto err = bucketResponse.add_errorinfo();

		err->set_errortype("Sender");
		err->set_errorcode("NoSuchBucket");
		err->set_errormessage(m_error);
    }
	else
	{
		m_tags.clear();

		int retcode = d.executeQuery("DELETE from Msys_Bucket_Tags WHERE bucketKey = '" + m_tags + "' AND bucketId = '" + m_bucketId + "'");

		if (retcode != 0)
		{
			std::cout << "ExecuteQuery Failed" << std::endl;
			return;
		}
	}
}*/

////////////////////////////////////////////////////////////////change for bucket version/////////////////
void bucket::put_Bucket_Version(s3service::s3bucket& bucketResponse,database& d)
{	
m_bucketVersion="Enable";
		    	int retcode = d.executeQuery("UPDATE Msys_Buckets SET bucketVersion= '" +m_bucketVersion+"' WHERE bucketId = '" + m_bucketId + "'");

    	if (retcode != 0)
		{
			std::cout << "ExecuteQuery Failed" << std::endl;
			return;
		}
	bucketResponse.set_version(m_bucketVersion);
}

void bucket::get_Bucket_Version(s3service::s3bucket& bucketResponse,database& d)

{	
	std::vector<std::vector<std::string>> version;
	int retcode = d.executeQuery("SELECT bucketVersion from Msys_Buckets WHERE bucketId = '" + m_bucketId + "'",version);
    
        if (retcode != 0)
        {
            std::cout << "ExecuteQuery Failed" << std::endl;
            return;
        }
    bucketResponse.set_version(version[0][0]);
}

std::string bucket::getBucketName()
{
	return m_bucketName;
}

std::string bucket::getBucketId()
{
	return m_bucketId;
}

std::string bucket::getArn()
{
	return m_arn;
}

std::string bucket::getAccountId()
{
	return m_accountId;
}

std::string bucket::getCreationTimestamp()
{
	return m_creationTimestamp;
}

std::map<std::string, std::string> bucket::getTags()
{
	return m_tags;
}

std::string bucket::getErrorMessage()
{
	return m_error;
}

bool bucket::doesBucketExists()
{
	return m_bExists;
}

std::string bucket::getBucketVersion()
{
    return m_bucketVersion;
}


bucket::~bucket()
{

}
