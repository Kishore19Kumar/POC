#include "credential"
credential::credential(string username)
{
	m_username = username;
}
credential::credential(string password, string username)
{
	m_password = password;
	m_username = username;
}
bool credential::isvalidPassword(s3service::s3account& accountResponse)
{
	//check the lenght of password it should be greater then 8
	//null password is not allowed
	//need to have spl character
	//min 1 upper case and min 1 lower case
	//1 number
	int len = m_password.length();
	int f_number = 0;
	int f_az = 0;
	int f_AZ = 0;
	if((len >=8) && (m_password !=NULL) && (len <=16))
	{
		for(int i=0;i<len;i++)
		{
			
			if(m_password[i]==" ")
			{
				auto err = accountResponse.add_errorinfo();
				m_error = "Password has some space " + m_password + " re-enter password";
				err->set_errortype("Password");
				err->set_errorcode("Invalid password");
				err->set_errormessage(m_error);
				return false;
			}
			//for number check
			else if((m_password[i] >= '0' ) && (m_password[i] <= '9'))
			{
				f_number=1;
			}
			//for small letter
			else if((m_password[i] >= 97 ) && (m_password[i] <= 122))
			{
				f_az=1;
			}
			//for captial letter
			else if((m_password[i] >= 65 ) && (m_password[i] <= 90))
			{
				f_AZ=1;
			}
			//for spl char
			else if((m_password[i] != '@' ) && (m_password[i] != '#'))
			{
				auto err = accountResponse.add_errorinfo();
				m_error = "Password must have one special character of @ and # " + m_password + " re-enter password";
				err->set_errortype("Password");
				err->set_errorcode("Invalid password");
				err->set_errormessage(m_error);
				return false;
			}
			
		}
	
		if((f_number != 1) && (f_az != 1) && (f_AZ != 1))
		{
			auto err = accountResponse.add_errorinfo();
			m_error = "Password must have one number, one small letter and one captial letter " + m_password + " re-enter password";
			err->set_errortype("Password");
			err->set_errorcode("Invalid password");
			err->set_errormessage(m_error);
			return false;
		}
			
	        else 
	        {
	        	return true;
	        }
	}
	//for length
	else{
	auto err = accountResponse.add_errorinfo();
	m_error = "Password must have length of min 8 to max 16 and should not be null character" + m_password + " re-enter password";
	err->set_errortype("Password");
	err->set_errorcode("Invalid password");
	err->set_errormessage(m_error);
	return false; 
	}
}
bool credential::isvalidusername(s3service::s3user& userResponse)
{
	int len = m_username.length();
	if((len >= 5) && (len<=20) && (m_username != NULL))
	{
		for(auto a:m_username)
		{
			if(a==" ")
			{
				auto err = userResponse.add_errorinfo();
				m_error = "Name should not have space " + m_username;
				err->set_errortype("User Name"); 
				err->set_errorcode("Invalide Username");
				err->set_errormessage(m_error);
				return false;
			}
			else if(a!='_')
			{
				auto err = userResponse.add_errorinfo();
				m_error = "Name should not have special character other than '_' " + m_username;
				err->set_errortype("User Name"); 
				err->set_errorcode("Invalide Username");
				err->set_errormessage(m_error);
				return false;
			}
			
		}
		return true;
	}
	else
	{
		auto err = userResponse.add_errorinfo();
		m_error = "Name should have length min of 5 character and max 20 character " + m_username;
		err->set_errortype("User Name"); 
		err->set_errorcode("Invalide Username");
		err->set_errormessage(m_error);	
		return false;
	}
	
}

bool credential::isvalidaccname(s3service::s3account& accountResponse)
{
	int len = m_username.length();
	if((len >= 5) && (len<=20) && (m_username != NULL))
	{
		for(auto a:m_username)
		{
			if(a==" ")
			{
				auto err = accountResponse.add_errorinfo();
				m_error = "Name should not have space " + m_username;
				err->set_errortype("User Name"); 
				err->set_errorcode("Invalide Username");
				err->set_errormessage(m_error);
				return false;
			}
			else if(a!='_')
			{
				auto err = accountResponse.add_errorinfo();
				m_error = "Name should not have special character other than '_' " + m_username;
				err->set_errortype("User Name"); 
				err->set_errorcode("Invalide Username");
				err->set_errormessage(m_error);
				return false;
			}
			
		}
		return true;
	}
	else
	{
		auto err = accountResponse.add_errorinfo();
		m_error = "Name should have length min of 5 character and max 20 character " + m_username;
		err->set_errortype("User Name"); 
		err->set_errorcode("Invalide Username");
		err->set_errormessage(m_error);	
		return false;
	}
	
}
